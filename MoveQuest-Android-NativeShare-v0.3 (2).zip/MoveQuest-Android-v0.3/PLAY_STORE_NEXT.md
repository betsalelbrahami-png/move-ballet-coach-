# Avant Google Play

1. Tester v10 + APK v0.4 sur un vrai Android : vidéo, durée, détection personnes, musique, Instagram/Facebook/YouTube, notification.
2. Brancher un backend réel pour la communauté et les votes multi-utilisateurs.
3. Ajouter politique de confidentialité + écran de consentement/compte si nécessaire.
4. Générer une clé d'upload et un AAB release signé. Conserver la clé en lieu sûr.
5. Préparer icône 512x512, feature graphic, captures d'écran, description, Data safety, content rating et audience cible.
6. Ne pas activer la localisation en arrière-plan pour la première soumission sans nécessité : cela ajoute une revue de permission sensible. La v0.4 déclenche la notification native depuis la localisation active de l'app.
