package com.danceworldquest.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_MEDIA = 1002;
    private static final int REQ_FILE = 1003;
    private static final int REQ_NOTIFICATIONS = 1004;
    private static final String CHANNEL_NEARBY = "dwq_nearby_missions";

    private static final String GAME_URL =
        "https://appassets.androidplatform.net/assets/index.html";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    private final Object videoLock = new Object();
    private StringBuilder pendingVideoBase64;
    private String pendingMime = "video/webm";
    private String pendingTarget = "";
    private String pendingTitle = "DANCE WORLD QUEST";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        requestNotificationPermissionIfNeeded();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new NotifyBridge(), "AndroidNotify");

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                    "window.__DWQ_ANDROID=true;window.__DWQ_ANDROID_SHARE_CHUNKED=true;",
                    null
                );
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("appassets.androidplatform.net") || host.endsWith("jsdelivr.net") || host.endsWith("openstreetmap.org") || host.endsWith("cartocdn.com"))) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(
                        new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        },
                        REQ_LOCATION
                    );
                }
            }

            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Impossible d’ouvrir les musiques", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        webView.loadUrl(GAME_URL);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                new String[]{Manifest.permission.POST_NOTIFICATIONS},
                REQ_NOTIFICATIONS
            );
        }
    }

    private void handleWebPermission(PermissionRequest request) {
        List<String> needed = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (needed.isEmpty()) request.grant(request.getResources());
        else {
            pendingWebPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_LOCATION && pendingGeoCallback != null) {
            boolean granted = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }

        if (requestCode == REQ_MEDIA && pendingWebPermission != null) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) pendingWebPermission.grant(pendingWebPermission.getResources());
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    public class ShareBridge {
        @JavascriptInterface
        public void beginVideo(String mimeType, String target, String title) {
            synchronized (videoLock) {
                pendingVideoBase64 = new StringBuilder();
                pendingMime = mimeType == null || mimeType.isEmpty() ? "video/webm" : mimeType;
                pendingTarget = target == null ? "" : target;
                pendingTitle = title == null || title.isEmpty() ? "DANCE WORLD QUEST" : title;
            }
        }

        @JavascriptInterface
        public void appendVideoChunk(String chunk) {
            if (chunk == null) return;
            synchronized (videoLock) {
                if (pendingVideoBase64 != null) pendingVideoBase64.append(chunk);
            }
        }

        @JavascriptInterface
        public void finishVideo() {
            final String encoded;
            final String mime;
            final String target;
            final String title;
            synchronized (videoLock) {
                if (pendingVideoBase64 == null || pendingVideoBase64.length() == 0) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Vidéo vide", Toast.LENGTH_LONG).show());
                    return;
                }
                encoded = pendingVideoBase64.toString();
                mime = pendingMime;
                target = pendingTarget;
                title = pendingTitle;
                pendingVideoBase64 = null;
            }
            writeAndShare(encoded, mime, target, title);
        }

        // Compatibility with v9 and older pages.
        @JavascriptInterface
        public void shareVideo(String dataUrl, String mimeType, String target, String title) {
            if (dataUrl == null) return;
            int comma = dataUrl.indexOf(',');
            String encoded = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
            writeAndShare(encoded, mimeType, target, title);
        }
    }

    public class NotifyBridge {
        @JavascriptInterface
        public void nearby(String title, String body) {
            runOnUiThread(() -> showNearbyNotification(title, body));
        }
    }

    private void writeAndShare(String encoded, String mimeType, String target, String title) {
        new Thread(() -> {
            try {
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                boolean mp4 = mimeType != null && mimeType.toLowerCase().contains("mp4");
                String extension = mp4 ? "mp4" : "webm";

                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("cache");

                File video = new File(dir, "dance-world-quest-" + System.currentTimeMillis() + "." + extension);
                try (FileOutputStream out = new FileOutputStream(video)) {
                    out.write(bytes);
                }

                Uri uri = FileProvider.getUriForFile(
                    MainActivity.this,
                    getPackageName() + ".fileprovider",
                    video
                );
                runOnUiThread(() -> launchShare(uri, mimeType, target, title));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "Impossible de préparer cette vidéo",
                    Toast.LENGTH_LONG
                ).show());
            }
        }).start();
    }

    private void launchShare(Uri uri, String mimeType, String target, String title) {
        Intent share = new Intent(Intent.ACTION_SEND);
        // Wildcard improves discovery for apps that do not advertise video/webm explicitly.
        share.setType("video/*");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, "DANCE WORLD QUEST — " + (title == null ? "Mission" : title));
        share.putExtra(Intent.EXTRA_SUBJECT, "DANCE WORLD QUEST");
        share.setClipData(ClipData.newRawUri("Dance World Quest video", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        String packageName = packageForTarget(target);
        if (packageName != null) {
            Intent targeted = new Intent(share);
            targeted.setPackage(packageName);
            targeted.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                startActivity(targeted);
                return;
            } catch (ActivityNotFoundException ignored) {
                Toast.makeText(this, target + " n’est pas disponible, ouverture du menu de partage", Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) {
                // Some versions reject the specific target for a codec; chooser can still offer compatible apps.
            }
        }

        try {
            startActivity(Intent.createChooser(share, "Partager Dance World Quest"));
        } catch (Exception e) {
            Toast.makeText(this, "Aucune application de partage disponible", Toast.LENGTH_LONG).show();
        }
    }

    private String packageForTarget(String target) {
        if (target == null) return null;
        if ("Instagram".equalsIgnoreCase(target)) return "com.instagram.android";
        if ("Facebook".equalsIgnoreCase(target)) return "com.facebook.katana";
        if ("YouTube".equalsIgnoreCase(target)) return "com.google.android.youtube";
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_NEARBY,
                "Missions proches",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Alerte quand une mission Dance World Quest est proche");
            channel.enableVibration(true);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void showNearbyNotification(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) return;

        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(
            this,
            0,
            open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_NEARBY)
            .setSmallIcon(com.danceworldquest.app.R.drawable.ic_launcher)
            .setContentTitle(title == null ? "Mission proche" : title)
            .setContentText(body == null ? "Une mission Dance World Quest est près de toi" : body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        manager.notify(4100 + (int)(System.currentTimeMillis() % 700), builder.build());
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
