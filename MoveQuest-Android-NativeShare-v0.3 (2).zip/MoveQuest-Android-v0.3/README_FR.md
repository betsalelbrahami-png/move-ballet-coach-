# Dance World Quest Android v0.4 beta

Cette version Android embarque Dance World Quest v10 directement dans l’APK et ajoute : partage natif chunké vers Instagram, Facebook et YouTube, sélecteur de musique Android, notifications natives de mission proche, permissions caméra/micro/GPS, et nom/package finalisés avant la préparation Google Play.

Le partage dépend aussi du format vidéo produit par Android WebView. La page v10 demande MP4 lorsqu'il est disponible et utilise WebM en repli. Le menu de partage Android est utilisé en secours si une application refuse un format.

La communauté de la v10 est fonctionnelle en mode local/démo. Pour que les votes proviennent réellement de plusieurs téléphones, il faudra brancher un backend partagé avant la publication publique.
