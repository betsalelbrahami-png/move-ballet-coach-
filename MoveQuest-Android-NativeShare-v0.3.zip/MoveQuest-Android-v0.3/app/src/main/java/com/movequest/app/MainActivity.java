package com.movequest.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_MEDIA = 1002;
    private static final int REQ_FILE = 1003;

    private static final String GAME_URL =
        "https://betsalelbrahami-png.github.io/move-ballet-coach-/move-quest-simple-v4.html";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                String js =
                    "(function(){"
                    + "window.share=async function(target){"
                    + "if(!window.S||!S.videoBlob){if(window.toast)toast('Filme d’abord');return;}"
                    + "var reader=new FileReader();"
                    + "reader.onload=function(){"
                    + "try{AndroidShare.shareVideo(String(reader.result),S.videoBlob.type||'video/webm',target,(S.active&&S.active.title)||'MOVE QUEST');}"
                    + "catch(e){if(window.toast)toast('Partage Android indisponible');}"
                    + "};"
                    + "reader.readAsDataURL(S.videoBlob);"
                    + "};"
                    + "})();";

                view.evaluateJavascript(js, null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(
                        new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        },
                        REQ_LOCATION
                    );
                }
            }

            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                startActivityForResult(intent, REQ_FILE);
                return true;
            }
        });

        webView.loadUrl(GAME_URL);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
    }

    private void handleWebPermission(PermissionRequest request) {
        List<String> needed = new ArrayList<>();

        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.RECORD_AUDIO);
            }
        }

        if (needed.isEmpty()) {
            request.grant(request.getResources());
        } else {
            pendingWebPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_LOCATION && pendingGeoCallback != null) {
            boolean granted = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }

        if (requestCode == REQ_MEDIA && pendingWebPermission != null) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                pendingWebPermission.grant(pendingWebPermission.getResources());
            } else {
                pendingWebPermission.deny();
            }

            pendingWebPermission = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK
                    && data != null
                    && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }

            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    public class ShareBridge {
        @JavascriptInterface
        public void shareVideo(
                String dataUrl,
                String mimeType,
                String target,
                String title) {
            runOnUiThread(() ->
                shareVideoNative(dataUrl, mimeType, target, title)
            );
        }
    }

    private void shareVideoNative(
            String dataUrl,
            String mimeType,
            String target,
            String title) {
        try {
            int comma = dataUrl.indexOf(',');
            String encoded =
                comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;

            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);

            boolean mp4 =
                mimeType != null && mimeType.toLowerCase().contains("mp4");
            String extension = mp4 ? "mp4" : "webm";

            File dir = new File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();

            File video = new File(
                dir,
                "move-quest-" + System.currentTimeMillis() + "." + extension
            );

            try (FileOutputStream out = new FileOutputStream(video)) {
                out.write(bytes);
            }

            Uri uri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".fileprovider",
                video
            );

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(
                mimeType == null || mimeType.isEmpty()
                    ? "video/*"
                    : mimeType
            );
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT, "MOVE QUEST — " + title);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            String packageName = null;
            if ("Instagram".equalsIgnoreCase(target)) {
                packageName = "com.instagram.android";
            } else if ("Facebook".equalsIgnoreCase(target)) {
                packageName = "com.facebook.katana";
            }

            if (packageName != null) {
                share.setPackage(packageName);
                try {
                    startActivity(share);
                    return;
                } catch (ActivityNotFoundException ignored) {
                    share.setPackage(null);
                }
            }

            startActivity(
                Intent.createChooser(share, "Partager Move Quest")
            );
        } catch (Exception e) {
            Toast.makeText(
                this,
                "Impossible de partager cette vidéo",
                Toast.LENGTH_LONG
            ).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
