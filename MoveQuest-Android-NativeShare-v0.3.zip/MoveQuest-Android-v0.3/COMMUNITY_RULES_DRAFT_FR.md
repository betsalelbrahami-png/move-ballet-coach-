# Règles de la Communauté — brouillon

Les utilisateurs doivent avoir l'accord des personnes filmées avant de publier. Sont interdits : contenu sexuel, violent, haineux, humiliant, harcèlement, contenu illégal, mise en danger, usurpation ou contenu portant atteinte aux droits d'autrui.

Chaque vidéo et utilisateur doit pouvoir être signalé ou bloqué. Les signalements doivent être examinés et les contenus/utilisateurs en infraction doivent pouvoir être masqués ou supprimés côté serveur.

Les votes servent à valider les missions créatives et techniques. L'utilisateur ne peut pas voter pour sa propre vidéo.
