# Politique de confidentialité — brouillon

Dance World Quest utilise la localisation pour vérifier l'accès aux missions et afficher les missions proches. La caméra sert à enregistrer les vidéos de mission. L'application peut utiliser les notifications pour signaler une mission proche ou un événement.

Les vidéos de mission destinées à la Communauté, les votes, le profil, le pays et les scores devront être synchronisés avec le service serveur avant la mise en production. La politique finale devra identifier l'opérateur du service, l'hébergeur, les durées de conservation, les mécanismes de suppression de compte/données, les transferts éventuels, les coordonnées de contact et les droits applicables aux utilisateurs.

Le partage vers Instagram, Facebook, YouTube ou d'autres applications est optionnel et déclenché uniquement par l'utilisateur.

Ce document est un brouillon technique et doit être finalisé avant publication.
