package com.danceworldquest.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_MEDIA = 1002;
    private static final int REQ_FILE = 1003;
    private static final String BASE_URL = "https://betsalelbrahami-png.github.io/move-ballet-coach-/";
    private static final String CHANNEL_NEARBY = "dwq_nearby_missions";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    private final Object videoLock = new Object();
    private StringBuilder pendingVideoBase64;
    private String pendingMime = "video/webm";
    private String pendingTarget = "";
    private String pendingTitle = "DANCE WORLD QUEST";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new NotifyBridge(), "AndroidNotify");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.endsWith("github.io") || host.endsWith("jsdelivr.net") || host.endsWith("openstreetmap.org") || host.endsWith("cartocdn.com"))) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Impossible d’ouvrir les musiques", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        try {
            String html = readAssetText("www/index.html");
            webView.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", BASE_URL);
        } catch (Exception e) {
            Toast.makeText(this, "Impossible de charger Dance World Quest", Toast.LENGTH_LONG).show();
        }
    }

    private String readAssetText(String path) throws Exception {
        try (InputStream in = getAssets().open(path); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void handleWebPermission(PermissionRequest request) {
        List<String> needed = new ArrayList<>();
        List<String> allowedResources = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                allowedResources.add(resource);
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(Manifest.permission.CAMERA);
                }
            }
        }
        if (allowedResources.isEmpty()) {
            request.deny();
            return;
        }
        if (needed.isEmpty()) {
            request.grant(allowedResources.toArray(new String[0]));
        } else {
            pendingWebPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && pendingGeoCallback != null) {
            boolean granted = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
        if (requestCode == REQ_MEDIA && pendingWebPermission != null) {
            boolean cameraGranted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
            if (cameraGranted) pendingWebPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    public class ShareBridge {
        @JavascriptInterface
        public void beginVideo(String mimeType, String target, String title) {
            synchronized (videoLock) {
                pendingVideoBase64 = new StringBuilder();
                pendingMime = mimeType == null || mimeType.isEmpty() ? "video/webm" : mimeType;
                pendingTarget = target == null ? "" : target;
                pendingTitle = title == null || title.isEmpty() ? "DANCE WORLD QUEST" : title;
            }
        }

        @JavascriptInterface
        public void appendVideoChunk(String chunk) {
            if (chunk == null) return;
            synchronized (videoLock) {
                if (pendingVideoBase64 != null) pendingVideoBase64.append(chunk);
            }
        }

        @JavascriptInterface
        public void finishVideo() {
            final String encoded;
            final String mime;
            final String target;
            final String title;
            synchronized (videoLock) {
                if (pendingVideoBase64 == null || pendingVideoBase64.length() == 0) return;
                encoded = pendingVideoBase64.toString();
                mime = pendingMime;
                target = pendingTarget;
                title = pendingTitle;
                pendingVideoBase64 = null;
            }
            writeAndShare(encoded, mime, target, title);
        }

        @JavascriptInterface
        public void shareVideo(String dataUrl, String mimeType, String target, String title) {
            int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
            String encoded = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
            writeAndShare(encoded, mimeType, target, title);
        }
    }

    private void writeAndShare(String encoded, String mimeType, String target, String title) {
        new Thread(() -> {
            try {
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                String mime = mimeType == null || mimeType.isEmpty() ? "video/webm" : mimeType;
                String ext = mime.contains("mp4") ? "mp4" : "webm";
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, "dance-world-quest-" + System.currentTimeMillis() + "." + ext);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
                runOnUiThread(() -> shareFile(uri, mime, target, title));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Impossible de partager cette vidéo", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void shareFile(Uri uri, String mime, String target, String title) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_TEXT, "DANCE WORLD QUEST — " + title);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        String pkg = null;
        if ("instagram".equalsIgnoreCase(target)) pkg = "com.instagram.android";
        else if ("facebook".equalsIgnoreCase(target)) pkg = "com.facebook.katana";
        else if ("youtube".equalsIgnoreCase(target)) pkg = "com.google.android.youtube";
        if (pkg != null) {
            intent.setPackage(pkg);
            try { startActivity(intent); return; }
            catch (ActivityNotFoundException ignored) { intent.setPackage(null); }
        }
        startActivity(Intent.createChooser(intent, "Partager Dance World Quest"));
    }

    public class NotifyBridge {
        @JavascriptInterface
        public void nearby(String title, String text) {
            runOnUiThread(() -> showNearbyNotification(title, text));
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_NEARBY, "Missions proches", NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void showNearbyNotification(String title, String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_NEARBY)
                .setSmallIcon(com.danceworldquest.app.R.drawable.ic_launcher)
                .setContentTitle(title == null ? "Mission proche" : title)
                .setContentText(text == null ? "Une mission Dance World Quest est près de toi." : text)
                .setAutoCancel(true);
        try { NotificationManagerCompat.from(this).notify(2207, b.build()); } catch (SecurityException ignored) {}
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
