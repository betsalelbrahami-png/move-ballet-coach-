# Dance World Quest — préparation Google Play v1.1

## État technique
- package Android : `com.danceworldquest.app`
- versionCode : 11
- versionName : 1.1.0
- compileSdk / targetSdk : 36
- caméra, GPS et partage externe conservés ; leur logique interne validée reste inchangée
- divulgation claire ajoutée avant la première demande GPS et avant la première demande caméra
- backend partagé Supabase connecté
- comptes joueurs, profils, vidéos privées, votes, XP serveur, classements, signalements et blocages configurés
- suppression de compte disponible dans l’application via une fonction serveur dédiée
- page web externe de suppression préparée
- page publique de politique de confidentialité avec formulaire de contact préparée
- les coordonnées GPS exactes sont utilisées temporairement pour la validation puis supprimées du dossier serveur de soumission
- Instagram/Facebook/YouTube restent optionnels

## 13+ / contrôle d’âge
- lancement prévu : 13+
- écran neutre : saisie libre de la date de naissance, sans afficher l’âge requis dans l’écran de saisie
- la date de naissance est calculée localement puis jetée ; elle n’est pas envoyée au backend
- le backend conserve seulement la confirmation d’éligibilité et la version des conditions acceptées
- la Communauté, les votes, les vidéos et le classement partagé sont verrouillés côté serveur tant que l’éligibilité et les règles actuelles ne sont pas confirmées

## Communauté / UGC
- consentement aux règles versionné côté serveur
- impossible de voter pour sa propre vidéo
- un vote maximum par joueur et par soumission
- minimum de 5 votes pour un verdict communautaire
- bonus de vote plafonné côté serveur
- fonctions internes XP non appelables directement par les joueurs
- mission simple auto-XP limitée côté serveur à `Dance Spot` et contrôlée par durée/GPS
- signalement vidéo, signalement utilisateur et blocage utilisateur
- auto-masquage de contenus fortement signalés en attente d’examen
- vidéos stockées dans un bucket privé
- GPS exact non lisible par les autres clients

## Gameplay v1.1
- Battle : 25 % de la génération pondérée
- mission solo générique « danse 10 s » : 3 % seulement
- missions techniques précises fortement majoritaires parmi les missions solo filmées
- 20 techniques disponibles dont Moonwalk, Backpack/Floss, Running Man, Shuffle, Charleston, Body Wave, Arm Wave, Robot, Tutting, Heel-Toe, Side Glide, etc.
- missions vitesse : 1000 XP de base, catégorie standard la plus rémunératrice
- Weekly Jam : rendez-vous hebdomadaire présent dans la génération de missions
- classement national et mondial alimenté par l’XP serveur

## Avant production Google Play
1. Publier `privacy.html` sur une URL publique et vérifier que le nom public du développeur correspond à la fiche Google Play.
2. Publier `delete-account.html` sur une URL publique et déclarer cette URL dans Play Console.
3. Créer/conserver hors du dépôt public une clé d’upload Android et produire un AAB release signé.
4. Compléter Data safety, Content rating, App access, Ads et Target audience. Pour le choix 13+, viser les groupes appropriés à partir de 13 ans et ne pas sélectionner les groupes sous 13 ans.
5. Mettre en place une procédure humaine régulière de traitement des signalements et sanctions.
6. Tester sur plusieurs comptes/appareils : compte, contrôle d’âge, GPS, caméra, upload, vote, XP, classement, blocage, signalement et suppression.
7. Effectuer le parcours de test Google Play applicable au compte développeur.

Une application ne peut pas être considérée comme effectivement publiée avant signature, formulaires Play Console, tests réels et validation Google Play.
