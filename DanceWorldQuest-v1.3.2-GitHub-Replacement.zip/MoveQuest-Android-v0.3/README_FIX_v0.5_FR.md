Dance World Quest v0.5 — correctif stabilité

- GPS et caméra revenus au flux WebView qui fonctionnait auparavant.
- Suppression de la demande de notification au démarrage, qui pouvait entrer en concurrence avec les permissions GPS/caméra.
- v10.1 intégrée localement dans l'APK.
- 90 missions générales + 16 missions garanties autour du joueur lorsque le GPS est actif.
- Filtre anti-eau pour Méditerranée, Kinneret, Mer Morte et golfe d'Eilat.
- Communauté, votes, sons XP et partage Android conservés.
