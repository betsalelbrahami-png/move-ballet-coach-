# Dance World Quest — préparation Google Play v1.0

État technique du client Android :
- package: com.danceworldquest.app
- versionCode 10 / versionName 1.0.0
- compileSdk / targetSdk: 36
- caméra, GPS, notifications et partage externe restent séparés du gameplay principal
- Community: consentement avant publication, signalement de contenu et blocage d'utilisateur présents dans l'interface
- les vidéos de mission sont destinées à la Communauté de l'application; le partage Instagram/Facebook est optionnel

À terminer avant publication production :
1. Connecter un backend partagé pour comptes, vidéos, votes, classements et événements. La version cliente garde actuellement les vidéos/votes localement.
2. Mettre en place une modération serveur réelle des signalements et sanctions.
3. Créer une clé d'upload Google Play et produire un Android App Bundle (.aab) signé. Ne jamais stocker la clé dans le dépôt public.
4. Publier une politique de confidentialité avec une URL publique et finaliser les Conditions de la Communauté.
5. Compléter Data safety, Content rating, App access, Ads, Target audience et déclarations de permissions dans Play Console.
6. Tester le flux caméra/GPS/vidéo sur plusieurs appareils et lancer le track de test exigé par le type de compte Play Console.

Ne pas considérer le projet comme publiable en production tant que les points 1–6 ne sont pas terminés.
