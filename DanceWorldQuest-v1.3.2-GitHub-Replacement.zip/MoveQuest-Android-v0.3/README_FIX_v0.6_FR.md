# Dance World Quest v0.6 — correctif caméra
- La page intégrée est chargée avec une base HTTPS GitHub Pages pour conserver une origine sécurisée.
- La caméra n'utilise plus le microphone : la piste audio vient uniquement de la musique choisie par le joueur.
- Permission Android CAMERA uniquement pour filmer; GPS inchangé.
- Erreur caméra affichée avec son vrai type si un appareil bloque encore l'accès.
