# Règles de la Communauté — Dance World Quest

Dernière mise à jour : 28 août 2026.

La Communauté Dance World Quest est réservée aux utilisateurs éligibles. Les vidéos servent principalement à prouver et faire évaluer des missions de danse.

En publiant une vidéo, l’utilisateur confirme avoir l’accord des personnes reconnaissables filmées. Si une personne mineure apparaît, l’utilisateur doit disposer de l’autorisation appropriée de son parent ou responsable légal.

Sont interdits : contenu sexuel ou sexualisant inapproprié, exploitation de mineurs, nudité sexuelle, violence réelle ou glorification de la violence, haine, harcèlement, humiliation, menaces, mise en danger, défis dangereux, contenu illégal, usurpation, divulgation d’informations privées, atteinte aux droits d’autrui et spam.

La Communauté peut noter ou départager une mission. Un joueur ne peut pas voter pour sa propre vidéo et ne peut voter qu’une fois sur une même soumission. Les tentatives de manipulation des votes, de l’XP, des missions vitesse ou des classements peuvent entraîner la suppression des points, du contenu ou du compte.

Chaque utilisateur peut signaler une vidéo, signaler un utilisateur et bloquer un utilisateur. Les contenus fortement signalés peuvent être masqués automatiquement en attente d’examen. L’opérateur doit examiner les signalements et peut masquer ou supprimer un contenu, limiter un compte ou supprimer un compte en cas de violation.
