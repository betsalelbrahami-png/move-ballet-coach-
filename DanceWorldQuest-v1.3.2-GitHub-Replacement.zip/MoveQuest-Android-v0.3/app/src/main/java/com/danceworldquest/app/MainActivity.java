package com.danceworldquest.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@UnstableApi
public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_MEDIA = 1002;
    private static final int REQ_FILE = 1003;
    private static final int REQ_NOTIFICATIONS = 1004;
    private static final String BASE_URL = "https://app.danceworldquest.local/";
    private static final String CHANNEL_NEARBY = "dwq_nearby_missions";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    private final Object videoLock = new Object();
    private File pendingVideoFile;
    private FileOutputStream pendingVideoOut;
    private String pendingMime = "video/webm";
    private String pendingTarget = "";
    private String pendingTitle = "DANCE WORLD QUEST";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new NotifyBridge(), "AndroidNotify");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                String host = uri.getHost();
                boolean sameApp = "https".equalsIgnoreCase(scheme) && "app.danceworldquest.local".equalsIgnoreCase(host);
                if (sameApp) return false;
                // All navigations away from the trusted app origin are opened outside the WebView.
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Impossible d’ouvrir les musiques", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        try {
            String html = readAssetText("www/index.html");
            webView.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", BASE_URL);
        } catch (Exception e) {
            Toast.makeText(this, "Impossible de charger Dance World Quest", Toast.LENGTH_LONG).show();
        }
    }

    private String readAssetText(String path) throws Exception {
        try (InputStream in = getAssets().open(path); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void handleWebPermission(PermissionRequest request) {
        List<String> needed = new ArrayList<>();
        List<String> allowedResources = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                allowedResources.add(resource);
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(Manifest.permission.CAMERA);
                }
            }
        }
        if (allowedResources.isEmpty()) {
            request.deny();
            return;
        }
        if (needed.isEmpty()) {
            request.grant(allowedResources.toArray(new String[0]));
        } else {
            pendingWebPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && pendingGeoCallback != null) {
            boolean granted = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
        if (requestCode == REQ_MEDIA && pendingWebPermission != null) {
            boolean cameraGranted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
            if (cameraGranted) pendingWebPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    public class ShareBridge {
        @JavascriptInterface
        public void beginVideo(String mimeType, String target, String title) {
            synchronized (videoLock) {
                cancelPendingVideoLocked();
                try {
                    pendingMime = mimeType == null || mimeType.isEmpty() ? "video/webm" : mimeType;
                    pendingTarget = target == null ? "" : target;
                    pendingTitle = title == null || title.isEmpty() ? "DANCE WORLD QUEST" : title;
                    String ext = pendingMime.contains("mp4") ? "mp4" : "webm";
                    File dir = new File(getCacheDir(), "shared");
                    if (!dir.exists()) dir.mkdirs();
                    pendingVideoFile = new File(dir, "dance-world-quest-" + System.currentTimeMillis() + "." + ext);
                    pendingVideoOut = new FileOutputStream(pendingVideoFile);
                } catch (Exception e) {
                    cancelPendingVideoLocked();
                    Log.e("DWQ_SHARE", "Unable to start streamed share", e);
                }
            }
        }

        @JavascriptInterface
        public void appendVideoChunk(String chunk) {
            if (chunk == null || chunk.isEmpty()) return;
            synchronized (videoLock) {
                if (pendingVideoOut == null) return;
                try {
                    byte[] bytes = Base64.decode(chunk, Base64.DEFAULT);
                    pendingVideoOut.write(bytes);
                } catch (Exception e) {
                    Log.e("DWQ_SHARE", "Unable to append streamed share chunk", e);
                    cancelPendingVideoLocked();
                }
            }
        }

        @JavascriptInterface
        public void cancelVideo() {
            synchronized (videoLock) { cancelPendingVideoLocked(); }
        }

        @JavascriptInterface
        public void finishVideo() {
            final File file;
            final String mime;
            final String target;
            final String title;
            synchronized (videoLock) {
                if (pendingVideoOut == null || pendingVideoFile == null) return;
                try { pendingVideoOut.flush(); pendingVideoOut.close(); } catch (Exception ignored) {}
                pendingVideoOut = null;
                file = pendingVideoFile;
                pendingVideoFile = null;
                mime = pendingMime;
                target = pendingTarget;
                title = pendingTitle;
            }
            if (!file.exists() || file.length() < 1) { try { file.delete(); } catch (Exception ignored) {} return; }
            runOnUiThread(() -> sharePreparedFile(file, mime, target, title));
        }
    }

    private void cancelPendingVideoLocked() {
        try { if (pendingVideoOut != null) pendingVideoOut.close(); } catch (Exception ignored) {}
        pendingVideoOut = null;
        if (pendingVideoFile != null) { try { pendingVideoFile.delete(); } catch (Exception ignored) {} }
        pendingVideoFile = null;
    }

    private void sharePreparedFile(File file, String mime, String target, String title) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            if (needsSocialMp4(target)) transcodeAndShareMp4(file, uri, mime, target, title);
            else shareFile(uri, mime, target, title);
        } catch (Exception e) {
            Log.e("DWQ_SHARE", "Unable to share streamed video", e);
            Toast.makeText(this, "Impossible de partager cette vidéo", Toast.LENGTH_LONG).show();
        }
    }

    private boolean needsSocialMp4(String target) {
        return "instagram".equalsIgnoreCase(target)
                || "facebook".equalsIgnoreCase(target)
                || "youtube".equalsIgnoreCase(target);
    }

    private void transcodeAndShareMp4(File inputFile, Uri fallbackUri, String fallbackMime, String target, String title) {
        File dir = new File(getCacheDir(), "shared");
        if (!dir.exists()) dir.mkdirs();
        File outputFile = new File(dir, "dance-world-quest-social-" + System.currentTimeMillis() + ".mp4");
        if (outputFile.exists()) outputFile.delete();
        Toast.makeText(this, "Conversion vidéo MP4…", Toast.LENGTH_SHORT).show();
        runSocialTransform(inputFile, outputFile, target, title, false);
    }

    private void runSocialTransform(File inputFile, File outputFile, String target, String title, boolean removeAudio) {
        try {
            if (outputFile.exists()) outputFile.delete();
            MediaItem mediaItem = MediaItem.fromUri(Uri.fromFile(inputFile));
            EditedMediaItem.Builder editedBuilder = new EditedMediaItem.Builder(mediaItem);
            if (removeAudio) editedBuilder.setRemoveAudio(true);
            EditedMediaItem editedMediaItem = editedBuilder.build();

            Transformer.Builder transformerBuilder = new Transformer.Builder(this)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setEncoderFactory(new DefaultEncoderFactory.Builder(this).setEnableFallback(true).build());
            if (!removeAudio) transformerBuilder.setAudioMimeType(MimeTypes.AUDIO_AAC);

            Transformer transformer = transformerBuilder
                    .addListener(new Transformer.Listener() {
                        @Override
                        public void onCompleted(Composition composition, ExportResult result) {
                            try {
                                if (!outputFile.exists() || outputFile.length() < 1024) {
                                    throw new IllegalStateException("MP4 output is empty");
                                }
                                if (!isSocialCompatibleMp4(outputFile)) {
                                    if (!removeAudio) {
                                        runSocialTransform(inputFile, outputFile, target, title, true);
                                        return;
                                    }
                                    throw new IllegalStateException("MP4 codecs are not social-compatible");
                                }
                                Uri mp4Uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", outputFile);
                                shareFile(mp4Uri, "video/mp4", target, title);
                            } catch (Exception e) {
                                Log.e("DWQ_SHARE", "MP4 ready but share failed", e);
                                Toast.makeText(MainActivity.this, "MP4 prêt mais partage impossible", Toast.LENGTH_LONG).show();
                            }
                        }

                        @Override
                        public void onError(Composition composition, ExportResult result, ExportException exception) {
                            Log.e("DWQ_SHARE", "Social transcode failed removeAudio=" + removeAudio + " code=" + exception.errorCode, exception);
                            if (!removeAudio) {
                                // Some WebView recordings contain an audio track that certain devices cannot decode.
                                // Retry as H.264 MP4 without audio so sharing still works; music can be added in the social app.
                                runSocialTransform(inputFile, outputFile, target, title, true);
                            } else {
                                Toast.makeText(MainActivity.this, "Conversion vidéo compatible impossible.", Toast.LENGTH_LONG).show();
                            }
                        }
                    })
                    .build();
            transformer.start(editedMediaItem, outputFile.getAbsolutePath());
        } catch (Exception e) {
            Log.e("DWQ_SHARE", "Social transcode setup failed removeAudio=" + removeAudio, e);
            if (!removeAudio) {
                runSocialTransform(inputFile, outputFile, target, title, true);
            } else {
                Toast.makeText(this, "Conversion vidéo compatible impossible.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private boolean isSocialCompatibleMp4(File file) {
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(file.getAbsolutePath());
            boolean hasH264 = false;
            boolean audioOk = true;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime == null) continue;
                if (mime.startsWith("video/")) hasH264 = "video/avc".equals(mime);
                if (mime.startsWith("audio/") && !"audio/mp4a-latm".equals(mime)) audioOk = false;
            }
            return hasH264 && audioOk;
        } catch (Exception e) {
            Log.e("DWQ_SHARE", "Unable to inspect MP4 codecs", e);
            return false;
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
        }
    }

    private void shareFile(Uri uri, String mime, String target, String title) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_TEXT, "DANCE WORLD QUEST — " + title);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        String pkg = null;
        if ("instagram".equalsIgnoreCase(target)) pkg = "com.instagram.android";
        else if ("facebook".equalsIgnoreCase(target)) pkg = "com.facebook.katana";
        else if ("youtube".equalsIgnoreCase(target)) pkg = "com.google.android.youtube";
        if (pkg != null) {
            intent.setPackage(pkg);
            try { startActivity(intent); return; }
            catch (ActivityNotFoundException ignored) { intent.setPackage(null); }
        }
        startActivity(Intent.createChooser(intent, "Partager Dance World Quest"));
    }

    public class NotifyBridge {
        @JavascriptInterface
        public void nearby(String title, String text) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                    return;
                }
                showNearbyNotification(title, text);
            });
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_NEARBY, "Missions proches", NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void showNearbyNotification(String title, String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_NEARBY)
                .setSmallIcon(com.danceworldquest.app.R.drawable.ic_launcher)
                .setContentTitle(title == null ? "Mission proche" : title)
                .setContentText(text == null ? "Une mission Dance World Quest est près de toi." : text)
                .setAutoCancel(true);
        try { NotificationManagerCompat.from(this).notify(2207, b.build()); } catch (SecurityException ignored) {}
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        synchronized (videoLock) { cancelPendingVideoLocked(); }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
