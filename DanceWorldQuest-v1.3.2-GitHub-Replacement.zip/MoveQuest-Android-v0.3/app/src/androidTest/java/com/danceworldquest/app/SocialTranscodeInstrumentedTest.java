package com.danceworldquest.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import android.content.Context;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.Looper;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@UnstableApi
@RunWith(AndroidJUnit4.class)
public class SocialTranscodeInstrumentedTest {

    @Test
    public void vp8OpusWebmBecomesH264AacMp4() throws Exception {
        File output = transcodeAsset("test_vp8_opus.webm", false);
        assertMp4Codecs(output, true);
    }

    @Test
    public void vp8SilentWebmBecomesH264Mp4() throws Exception {
        File output = transcodeAsset("test_vp8_silent.webm", false);
        assertMp4Codecs(output, false);
    }

    private File transcodeAsset(String assetName, boolean removeAudio) throws Exception {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        File input = new File(context.getCacheDir(), assetName);
        try (InputStream in = InstrumentationRegistry.getInstrumentation().getContext().getAssets().open(assetName);
             FileOutputStream out = new FileOutputStream(input)) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
        File output = new File(context.getCacheDir(), assetName + ".mp4");
        if (output.exists()) output.delete();

        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Handler main = new Handler(Looper.getMainLooper());
        main.post(() -> {
            try {
                MediaItem item = MediaItem.fromUri(android.net.Uri.fromFile(input));
                EditedMediaItem.Builder editBuilder = new EditedMediaItem.Builder(item);
                if (removeAudio) editBuilder.setRemoveAudio(true);
                Transformer.Builder builder = new Transformer.Builder(context)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setEncoderFactory(new DefaultEncoderFactory.Builder(context).setEnableFallback(true).build());
                if (!removeAudio) builder.setAudioMimeType(MimeTypes.AUDIO_AAC);
                Transformer transformer = builder.addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition composition, ExportResult result) {
                        latch.countDown();
                    }

                    @Override
                    public void onError(Composition composition, ExportResult result, ExportException exception) {
                        failure.set(exception);
                        latch.countDown();
                    }
                }).build();
                transformer.start(editBuilder.build(), output.getAbsolutePath());
            } catch (Throwable t) {
                failure.set(t);
                latch.countDown();
            }
        });

        assertTrue("Transformer timed out", latch.await(60, TimeUnit.SECONDS));
        if (failure.get() != null) fail("Transformer failed: " + failure.get());
        assertTrue("Output missing", output.exists());
        assertTrue("Output too small", output.length() > 1024);
        return output;
    }

    private void assertMp4Codecs(File file, boolean expectAudio) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(file.getAbsolutePath());
        boolean hasAvc = false;
        boolean hasAac = false;
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if ("video/avc".equals(mime)) hasAvc = true;
            if ("audio/mp4a-latm".equals(mime)) hasAac = true;
        }
        extractor.release();
        assertTrue("Expected H.264/AVC video", hasAvc);
        assertEquals("Unexpected AAC presence", expectAudio, hasAac);
    }
}
