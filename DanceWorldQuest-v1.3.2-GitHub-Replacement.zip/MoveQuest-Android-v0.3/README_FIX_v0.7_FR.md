# Dance World Quest v0.7 — corrections ciblées

Cette version conserve la base stable v0.6 (GPS + caméra) et modifie uniquement les points demandés :
- conversion native en MP4/H.264 avant partage Instagram/Facebook/YouTube ;
- beaucoup plus de missions dans les zones urbaines denses, particulièrement Tel Aviv/Gush Dan ;
- réserve permanente de missions dans le désert et les zones isolées ;
- rotation automatique des spots toutes les 48 à 72 heures ;
- chaque rotation déplace le spot d'environ 1 à 2 km, sans rester automatiquement dans la même rue ;
- une mission gagnée est verrouillée pour le joueur et immédiatement remplacée, y compris une mission de vitesse ;
- répartition des types : environ 65% solo, 25% Battle, très peu de Family.

GPS, caméra et logique de permissions v0.6 n'ont pas été modifiés.
