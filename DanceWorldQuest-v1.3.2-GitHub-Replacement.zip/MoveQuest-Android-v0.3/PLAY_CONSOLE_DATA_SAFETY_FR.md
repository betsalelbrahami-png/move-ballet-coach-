# Dance World Quest — aide au formulaire Data safety Google Play

Document de préparation, à vérifier dans Play Console au moment de la soumission.

## Données principales
- Adresse e-mail / identifiant de compte : collectés pour authentification et gestion du compte.
- Pseudo, pays, ville : collectés pour profil et classements.
- Vidéos : collectées uniquement quand l’utilisateur valide une mission pour la Communauté.
- Activité dans l’application : missions, XP, votes, Battles et classement.
- Localisation précise : utilisée pour les missions géolocalisées ; peut être transmise de façon temporaire lors de la validation et est ensuite supprimée de la soumission.
- Date de naissance : utilisée localement pour l’écran neutre de contrôle d’âge ; **non envoyée et non stockée**.
- Publicité : aucune publicité ni SDK publicitaire dans la version actuelle.

## Finalités
Fonctionnalité de l’app, authentification, prévention de fraude, sécurité/modération, personnalisation géographique du gameplay et classement.

## Suppression
Suppression disponible dans l’app et page web externe dédiée. La suppression doit effacer le compte et les données associées.

## À confirmer dans Play Console
Les réponses exactes dépendent de la définition courante de « collected », « shared » et « ephemeral processing » affichée dans le formulaire au jour de la soumission. Vérifier aussi les pratiques documentées de Supabase et de tout SDK tiers inclus dans la build finale.
