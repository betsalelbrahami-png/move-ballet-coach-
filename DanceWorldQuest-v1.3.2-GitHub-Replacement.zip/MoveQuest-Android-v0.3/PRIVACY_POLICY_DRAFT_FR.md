# Politique de confidentialité — Dance World Quest

Dernière mise à jour : 28 août 2026.

Dance World Quest est un jeu mobile de missions de danse géolocalisées avec une Communauté réservée aux utilisateurs éligibles. L’application utilise uniquement les données nécessaires au fonctionnement du jeu et ne contient actuellement ni publicité ni SDK publicitaire.

## Données traitées
- **Compte** : adresse e-mail, identifiant de compte Supabase, pseudo, pays et ville.
- **Progression** : XP, résultats de missions, votes et données nécessaires aux classements.
- **Vidéos** : une vidéo de mission est envoyée au serveur uniquement lorsque l’utilisateur choisit de la valider dans la Communauté. Elle est stockée dans un espace privé et rendue accessible aux utilisateurs authentifiés éligibles selon les règles de blocage et de modération.
- **Localisation** : la localisation précise est utilisée pendant le jeu pour afficher les missions proches et vérifier l’arrivée dans une zone de mission. Lors d’une validation, les coordonnées nécessaires au contrôle peuvent être transmises au serveur. Elles sont supprimées du dossier de soumission après traitement et ne sont pas affichées dans la Communauté.
- **Contrôle d’âge** : la date de naissance saisie dans l’écran neutre est utilisée localement uniquement pour vérifier l’accès. La date de naissance elle-même n’est pas envoyée ni conservée sur le serveur ; le serveur conserve seulement la date de confirmation d’éligibilité et la version des règles acceptées.
- **Caméra** : l’accès à la caméra sert à enregistrer les vidéos de mission. L’application ne demande pas l’accès au microphone pour la caméra.

## Finalités
Ces données servent à fournir les missions, vérifier certaines conditions objectives, publier et noter les vidéos, calculer l’XP, afficher les classements, gérer les Battles et Weekly Jams, prévenir la fraude et modérer la Communauté.

## Prestataires et transferts
Supabase fournit l’authentification, la base de données, les fonctions serveur et le stockage vidéo. OpenStreetMap/Leaflet servent à afficher la carte. Les boutons de partage Instagram, Facebook, YouTube ou autres applications sont facultatifs et ne transfèrent une vidéo que lorsque l’utilisateur déclenche volontairement le partage.

## Sécurité et visibilité
Les vidéos sont stockées dans un bucket privé. Les règles d’accès côté serveur empêchent un utilisateur de voter pour sa propre soumission et limitent l’accès aux fonctions sensibles. Les coordonnées GPS exactes ne sont pas exposées aux autres joueurs. Les utilisateurs peuvent signaler une vidéo, signaler un joueur et bloquer un joueur.

## Conservation et suppression
Le compte, le profil, la progression serveur, les votes et les vidéos sont conservés tant que le compte existe ou aussi longtemps que nécessaire au fonctionnement et à la sécurité du service. L’utilisateur peut demander la suppression définitive du compte depuis l’application ou depuis la page web externe de suppression. La suppression du compte supprime les données de profil et les vidéos associées, sous réserve d’une éventuelle obligation légale de conservation qui devra être explicitement signalée si elle s’applique.

## Utilisateurs mineurs
La Communauté n’est pas destinée aux utilisateurs de moins de 13 ans. L’écran d’âge demande librement la date de naissance sans pré-remplissage et ne conserve pas cette date. Les utilisateurs qui publient une vidéo comportant une personne mineure doivent disposer de l’autorisation appropriée du parent ou responsable légal de cette personne.

## Contact
Une page web publique `privacy.html` contient un formulaire de contact confidentialité. Les demandes sont enregistrées de façon privée dans Supabase et ne sont pas lisibles par les joueurs. Avant la publication finale, vérifier que le **nom public du développeur ou de l’entité** correspond exactement à celui affiché sur la fiche Google Play.
