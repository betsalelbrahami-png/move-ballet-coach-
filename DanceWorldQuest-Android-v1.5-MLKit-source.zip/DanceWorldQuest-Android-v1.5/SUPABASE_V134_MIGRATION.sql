-- Applied to project lbmgmfpvxggxoboxfsib on 2026-09-01.
-- v1.3.4 social/progression additions: follows, positive reactions/HYPE, Daily Dance completion.
-- Kept here for reproducibility; do not re-apply blindly.

alter table public.profiles add column if not exists hype_total bigint not null default 0 check (hype_total >= 0);
-- See Supabase migration history: dance_world_quest_v134_social_progression
