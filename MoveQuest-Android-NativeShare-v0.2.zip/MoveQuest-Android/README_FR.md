# Move Quest — Android / Google Play

Version mobile de Move Quest basée sur la version v4 du jeu.

## Ce qui est déjà intégré
- Carte OpenStreetMap.
- GPS et missions liées à la position réelle.
- 4 familles : danse, collective, vitesse, spéciale.
- Liste des missions triées par distance.
- Caméra + micro.
- Choix d'un fichier musical depuis le téléphone.
- XP / niveaux.
- Structure Android native légère autour du jeu web.

## Configuration Android
- Application ID : `com.movequest.app`
- Version : `0.1.0`
- Min SDK : 26
- Compile SDK : 36
- Target SDK : 36
- Java : 17

Le projet cible déjà Android 16 / API 36, afin d'être compatible avec l'exigence Google Play qui entre en vigueur le 31 août 2026 pour les nouvelles applications et mises à jour.

## Tester sur un téléphone
1. Ouvrir le dossier dans Android Studio.
2. Laisser Android Studio installer Android SDK 36 et synchroniser Gradle.
3. Brancher un téléphone Android avec le débogage USB activé, ou créer un émulateur.
4. Cliquer sur Run.

## Préparer Google Play
Pour la publication finale :
1. Choisir définitivement le nom, l'icône et l'identifiant d'application.
2. Ajouter une politique de confidentialité.
3. Tester GPS, caméra, micro, musique et partage sur plusieurs téléphones.
4. Créer une clé de signature Android et la conserver précieusement.
5. Générer un Android App Bundle (.aab) signé.
6. Créer la fiche Google Play Console, captures d'écran et questionnaire de sécurité des données.

## Important
La version actuelle est une version de test Android. Pour la version publique, le partage direct des vidéos vers Instagram/Facebook devra être finalisé avec une intégration native plus robuste, et les missions collectives devront utiliser un serveur pour synchroniser plusieurs joueurs.
