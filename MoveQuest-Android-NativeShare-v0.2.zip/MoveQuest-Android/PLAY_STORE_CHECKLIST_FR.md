# Checklist Google Play — Move Quest

- [ ] Nom final de l'application
- [ ] Icône finale 512×512
- [ ] Bannière / visuels Play Store
- [ ] Captures d'écran téléphone
- [ ] Adresse e-mail de support
- [ ] Politique de confidentialité publique
- [ ] Déclaration localisation
- [ ] Déclaration caméra / micro
- [ ] Déclaration collecte et partage des données
- [ ] Règles de modération si des vidéos deviennent publiques
- [ ] Conditions d'utilisation
- [ ] Test fermé Google Play
- [ ] Tests sur Android 12, 13, 14, 15 et 16
- [ ] AAB signé
- [ ] VersionCode incrémenté à chaque mise à jour
