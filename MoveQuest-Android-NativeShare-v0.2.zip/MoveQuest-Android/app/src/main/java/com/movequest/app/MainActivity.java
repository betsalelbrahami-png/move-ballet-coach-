package com.movequest.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION=1001, REQ_MEDIA=1002, REQ_FILE=1003;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        webView=new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidShareBridge(),"AndroidShare");

        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){return loader.shouldInterceptRequest(request.getUrl());}
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest request){runOnUiThread(()->handleWebPermission(request));}
            @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback cb){
                if(hasLocationPermission()) cb.invoke(origin,true,false); else {pendingGeoOrigin=origin;pendingGeoCallback=cb;requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);}
            }
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");startActivityForResult(i,REQ_FILE);return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    private boolean hasLocationPermission(){return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private void handleWebPermission(PermissionRequest r){
        List<String> req=new ArrayList<>();
        for(String x:r.getResources()){
            if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.CAMERA);
            if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.RECORD_AUDIO);
        }
        if(req.isEmpty())r.grant(r.getResources());else{pendingWebPermission=r;requestPermissions(req.toArray(new String[0]),REQ_MEDIA);}
    }
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] g){super.onRequestPermissionsResult(code,p,g);
        if(code==REQ_LOCATION&&pendingGeoCallback!=null){boolean ok=hasLocationPermission();pendingGeoCallback.invoke(pendingGeoOrigin,ok,false);pendingGeoCallback=null;pendingGeoOrigin=null;}
        if(code==REQ_MEDIA&&pendingWebPermission!=null){boolean ok=true;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)ok=false;if(ok)pendingWebPermission.grant(pendingWebPermission.getResources());else pendingWebPermission.deny();pendingWebPermission=null;}
    }
    @Override @SuppressWarnings("deprecation") protected void onActivityResult(int code,int result,Intent data){super.onActivityResult(code,result,data);if(code==REQ_FILE&&fileCallback!=null){Uri[] r=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null)r=new Uri[]{data.getData()};fileCallback.onReceiveValue(r);fileCallback=null;}}

    public class AndroidShareBridge {
        @JavascriptInterface public void shareVideo(String dataUrl,String mimeType,String target,String title){runOnUiThread(()->doShare(dataUrl,mimeType,target,title));}
    }
    private void doShare(String dataUrl,String mimeType,String target,String title){
        try{
            int comma=dataUrl.indexOf(',');String encoded=comma>=0?dataUrl.substring(comma+1):dataUrl;byte[] bytes=Base64.decode(encoded,Base64.DEFAULT);
            String ext=(mimeType!=null&&mimeType.contains("mp4"))?"mp4":"webm";
            File dir=new File(getCacheDir(),"shared");if(!dir.exists())dir.mkdirs();
            File f=new File(dir,"move-quest-"+System.currentTimeMillis()+"."+ext);try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent i=new Intent(Intent.ACTION_SEND);i.setType(mimeType==null?"video/*":mimeType);i.putExtra(Intent.EXTRA_STREAM,uri);i.putExtra(Intent.EXTRA_TEXT,"MOVE QUEST — "+title);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            String pkg="instagram".equalsIgnoreCase(target)?"com.instagram.android":"facebook".equalsIgnoreCase(target)?"com.facebook.katana":null;
            if(pkg!=null){i.setPackage(pkg);try{startActivity(i);return;}catch(ActivityNotFoundException ignored){i.setPackage(null);}}
            startActivity(Intent.createChooser(i,"Partager Move Quest"));
        }catch(Exception e){Toast.makeText(this,"Impossible de partager cette vidéo",Toast.LENGTH_LONG).show();}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.loadUrl("about:blank");webView.destroy();webView=null;}super.onDestroy();}
}
